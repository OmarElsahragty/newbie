import { config } from "dotenv";
import { EnvironmentsEnum } from "../src/types";
config();

export default Object.freeze({
  environment: process.env.NODE_ENV as EnvironmentsEnum,

  cors: process.env.CORS ?? "*",

  port: parseInt(process.env.PORT ?? "5000"),

  mongoURI: process.env.MONGO_URI ?? "mongodb://localhost:27017/newbie",

  jwt: {
    secret: process.env.JWT_SECRET ?? "%o@J5o02Kumnw^d@O",
    lifeTime: process.env.JWT_LIFE_TIME ?? "1y",
  },
});
