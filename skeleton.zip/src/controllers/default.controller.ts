import { Request, Response, NextFunction } from "express";
import { ResponseInterface, IntervalInterface, Exception, NotFoundException } from "../types";
import { parser } from "../helpers";
import Service from "../services";

export default class DefaultController<T> {
  constructor(private service: Service<T>) {}

  protected response = async <T>(logic: Promise<T> | Promise<T>[], res: Response, next: NextFunction) => {
    try {
      const data = await Promise.allSettled(Array.isArray(logic) ? logic : [logic]);
      const { fulfilled = [], rejected = [] }: { fulfilled?: T[]; rejected?: Exception[] } = data.reduce(
        (acc: { fulfilled: T[]; rejected: Exception[] }, item) => {
          if (item.status === "fulfilled") {
            return Object.assign(acc, { fulfilled: acc.fulfilled.concat(item.value) });
          }

          return Object.assign(acc, { rejected: acc.rejected.concat([new Exception(item.reason)]) });
        },
        { fulfilled: [], rejected: [] }
      );

      if (!fulfilled.length && !rejected.length) throw new NotFoundException();
      if (!fulfilled.length) throw rejected;

      const response: ResponseInterface<T> = {
        data: fulfilled?.length < 2 ? fulfilled?.[0] : fulfilled,
        metadata: { errors: rejected.map(({ status, message }) => ({ status, message })) },
      };

      return res
        .status(
          !fulfilled.length
            ? rejected.reduce((acc: number, rejection) => (rejection.status < acc ? rejection.status : acc), 0)
            : 200
        )
        .send(response);
    } catch (err) {
      next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction) => {
    const filter = parser<Partial<T>>(req.query.filter?.toString());
    let intervals = parser<IntervalInterface | IntervalInterface[]>(req.query.intervals?.toString());
    if (intervals && !Array.isArray(intervals)) intervals = [intervals];
    const projection = parser(req.query.projection?.toString())
      ?.split(",")
      .reduce((acc: Record<string, 1>, item) => {
        const key = parser<string>(item.trim());

        if (!key) return acc;
        return Object.assign(acc, { [key]: 1 });
      }, {});

    return this.response(
      this.service.list(
        {
          filter,
          intervals,
          options: { flattenQuery: true, operation: parser(req.query.operation?.toString()) === "or" ? "or" : "and" },
        },
        {
          projection,
          sortBy: parser(req.query.sort?.toString()),
          sortDirection: req.query.direction?.toString() === "1" ? 1 : -1,
          page: parseInt(req.query.page?.toString() ?? "0"),
          pageLimit: parseInt(req.query.limit?.toString() ?? "10"),
          showAll: req.query.showAll?.toString() === "true",
        }
      ),
      res,
      next
    );
  };

  fetch = async (req: Request, res: Response, next: NextFunction) =>
    this.response(this.service.fetch({ id: req.params.id }), res, next);

  create = async (req: Request, res: Response, next: NextFunction) =>
    this.response(this.service.create(req.body), res, next);

  bulkCreate = async (req: Request, res: Response, next: NextFunction) =>
    this.response(this.service.bulkCreate(req.body), res, next);

  update = async (req: Request, res: Response, next: NextFunction) =>
    this.response(this.service.update({ id: req.params.id }, req.body), res, next);

  delete = async (req: Request, res: Response, next: NextFunction) =>
    this.response(this.service.delete({ id: req.params.id }), res, next);
}
