export { default } from "./default.controller";

export { default as userController } from "./user.controller";
