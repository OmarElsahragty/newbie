import { Router } from "express";
import { authorizedGuard } from "../guards";
import { validateMiddleware, errorHandlerMiddleware } from "../middleware";
import { $$$ import controllers $$$ } from "../controllers";
$$$ import authentication schema $$$

$$$ import routes $$$

const router = Router();

router.route("/ping").get((_req, res) => res.status(200).send({ alive: true, timestamp: new Date().toISOString() }));

$$$ authentication routes $$$

router.use(authorizedGuard);

// ****************************************** //

$$$ use routes $$$

// ****************************************** //

router.use(errorHandlerMiddleware);

export default router;
