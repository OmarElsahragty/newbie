import { Router } from "express";
import { authorizedGuard } from "../guards";
import { validateMiddleware, errorHandlerMiddleware } from "../middleware";

const router = Router();

router.route("/ping").get((_req, res) => res.status(200).send({ alive: true, timestamp: new Date().toISOString() }));

// ************** authentication ************** //

router.use(authorizedGuard);

// ****************************************** //

// ****************************************** //

router.use(errorHandlerMiddleware);

export default router;
