import { Router } from "express";
import { $$$ validate middleware $$$ errorHandlerMiddleware } from "../middleware";
$$$ import auth guard $$$
$$$ import auth controller $$$
$$$ import auth schema $$$

$$$ import routes $$$

const router = Router();

router.route("/ping").get((_req, res) => res.status(200).send({ alive: true, timestamp: new Date().toISOString() }));

$$$ auth routes $$$

$$$ use auth guard $$$

// ****************************************** //

$$$ use routes $$$

// ****************************************** //

router.use(errorHandlerMiddleware);

export default router;
