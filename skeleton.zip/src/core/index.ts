export { default as DefaultRepository } from "./repository.core";
export { default as DefaultService } from "./service.core";
export { default as DefaultController } from "./controller.core";
