import { verify } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { $$$ auth interface $$$, ForbiddenException } from "../types";
$$$ import auth service $$$
import config from "../../config";

export default async (req: Request, _res: Response, next: NextFunction) => {
  try {
    const token = req.headers.authorization;

    const data = (await new Promise((resolve, reject): void | Partial<$$$ auth interface $$$> => {
      if (!token) return reject();

      if (token.includes("Bearer")) {
        return verify(token.replace("Bearer ", ""), config.jwt.secret, (err, result) =>
          err || !result ? reject() : resolve(result)
        );
      }
    }).catch(() => undefined)) as void | Partial<$$$ auth interface $$$>;

    const client = data?._id && (await $$$ auth service $$$.fetch({ id: data._id }));

    if (!client) throw new ForbiddenException();
    req.client = client;

    next();
  } catch (err) {
    return next(err);
  }
};
