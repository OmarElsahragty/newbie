export { default as authorizedGuard } from "./authorization.guard";
