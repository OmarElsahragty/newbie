import { ZodError } from "zod";
import { MongoServerError } from "mongodb";
import { Request, Response, NextFunction } from "express";
import { ResponseInterface, Exception } from "../types";
import config from "../../config";

export default (
  error: Exception | Exception[] | ZodError | MongoServerError,
  _req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _next: NextFunction
) => {
  const errors = (Array.isArray(error) ? error : [error]).map(item => new Exception(item));
  const status = errors.reduce((acc, item) => (item.status > acc ? item.status : acc), 0);

  const response: ResponseInterface<void> = {
    metadata: {
      errors: config.environment === "PRODUCTION" ? errors.map(({ status, message }) => ({ status, message })) : errors,
    },
  };
  return res.status(status).send(response);
};
