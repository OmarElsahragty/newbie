export { userModel } from "./user.model";
