import * as repositories from "../repositories";

export const seeder = async () => {

$$$ authentication seed $$$
};
