import * as repositories from "../repositories";

/* eslint-disable @typescript-eslint/no-empty-function */

export const seeder = async () => {};
