import * as repositories from "../repositories";

export const seeder = async () => {
$$$ auth seed $$$
};
