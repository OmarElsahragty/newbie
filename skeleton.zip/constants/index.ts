export const schemas = Object.freeze({
  users: "users",
});

export const privileges = Object.freeze({});
