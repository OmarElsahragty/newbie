export const schemas = Object.freeze({
  $$$ schemas constants $$$
});

