import application from "./src/app";

application();
